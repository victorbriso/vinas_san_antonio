<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
      <title>Mi Empresa</title>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
      <?= $this->Html->css('corpN003/reset') ?>
      <?= $this->Html->css('corpN003/styles') ?>
      <?= $this->Html->script('corpN003/jquery.easing.1.3.js') ?>
      <?= $this->Html->script('corpN003/jquery.roundabout-1.0.min.js') ?>
      <?= $this->fetch('css') ?>
      <?= $this->fetch('script') ?>
      <script type="text/javascript">     
      $(document).ready(function() {
        $('#featured ul').roundabout({
          easing: 'easeOutInCirc',
          duration: 600
          });
        });
      </script>
    </head>
    <body>
    <div id="wrapper" class="container_12 clearfix">
    <!-- Text Logo -->
    <h1 id="logo" class="grid_4">Mi Empresa</h1>
    <!-- Navigation Menu -->
    <ul id="navigation" class="grid_8">
    <li><a href="#"><span class="meta">Escribenos</span><br />
    Contacto</a></li>
    <li><a href="#"><span class="meta">Noticias</span><br />
    Blog</a></li>
    <li><a href="#"><span class="meta">Últimos trabajos</span><br />
    Portafolio</a></li>
    <li><a href="#"><span class="meta">Quienes somos?</span><br />
    Nosotros</a></li>
    <li><a href="#" class="current"><span class="meta">Inicio</span><br />
    Home</a></li>
    </ul>
    <div class="hr grid_12">&nbsp;</div>
    <div class="clear"></div>
    <!-- Featured Image Slider -->
    <div id="featured" class="clearfix grid_12">
    <ul>
    <li> <a href="portfolio_single.html"> <span>Ver detalle</span><?= $this->Html->image('corpN003/600x300.gif') ?></a> </li>
    <li> <a href="single.html"> <span>Ver detalle</span> <?= $this->Html->image('corpN003/600x300.gif') ?> </a> </li>
    <li> <a href="full_width.html"> <span>Ver detalle</span> <?= $this->Html->image('corpN003/600x300.gif') ?> </a> </li>
    <li> <a href="#"> <span>Ver detalle</span> <?= $this->Html->image('corpN003/600x300.gif') ?> </a> </li>
    <li> <a href="#"> <span>Ver detalle</span> <?= $this->Html->image('corpN003/600x300.gif') ?> </a> </li>
    </ul>
    </div>
    <div class="hr grid_12 clearfix">&nbsp;</div>
    <!-- Caption Line -->
    <h2 class="grid_12 caption clearfix">Bienvenido a <span>Mi Empresa</span>, esto es un mensaje de <u>bienvenida.</u></h2>
    <div class="hr grid_12 clearfix quicknavhr">&nbsp;</div>
    <div id="quicknav" class="grid_12"> <a class="quicknavgrid_3 quicknav alpha" href="#">
    <h4 class="title ">Últimos trabajos</h4>
    <p>Cras vestibulum lorem et dui mollis sed posuere leo semper. </p>
    <p style="text-align:center;"><?= $this->Html->image('corpN003/Art_Artdesigner.lv.png') ?></p>
    </a> <a class="quicknavgrid_3 quicknav" href="#">
    <h4 class="title ">Sobre nosotros</h4>
    <p>Cras vestibulum lorem et dui mollis sed posuere leo semper. </p>
    <p style="text-align:center;"><?= $this->Html->image('corpN003/info.png') ?></p>
    </a> <a class="quicknavgrid_3 quicknav" href="#">
    <h4 class="title ">Blog</h4>
    <p>Cras vestibulum lorem et dui mollis sed posuere leo semper. </p>
    <p style="text-align:center;"><?= $this->Html->image('corpN003/Blog_Artdesigner.lv.png') ?></p>
    </a> <a class="quicknavgrid_3 quicknav" href="#">
    <h4 class="title ">Twitter</h4>
    <p>Cras vestibulum lorem et dui mollis sed posuere leo semper. </p>
    <p style="text-align:center;"><?= $this->Html->image('corpN003/hungry_bird.png') ?></p>
    </a> </div>
    <div class="hr grid_12 clearfix">&nbsp;</div>
    <!-- Footer -->
    <p class="grid_12 footer clearfix"> <a class="float right" href="#">Arriba</a></p>
    </div>
  </body>
</html>
