<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>beSMART</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?= $this->Html->css('corpN004/style') ?>
<?= $this->Html->css('corpN004/jquery.jcarousel') ?>
<?= $this->Html->script('corpN004/jquery-1.4.2.min.js') ?>
<?= $this->Html->script('corpN004/jquery.jcarousel.pack.js') ?>
<?= $this->Html->script('corpN004/func.js') ?>
<?= $this->fetch('css') ?>
<?= $this->fetch('script') ?>
</head>
<body>
<div class="shell">
  <div class="border">
    <div id="header">
      <h1 id="logo"><a href="#" class="notext">beSMART</a></h1>
      <div class="socials right">
        <ul>
          <li><a href="#" class="rss">RSS</a></li>
          <li><a href="#" class="fb">Facebook</a></li>
          <li class="last"><a href="#" class="twit">Twitter</a></li>
        </ul>
      </div>
      <div class="cl">&nbsp;</div>
    </div>
    <div id="navigation">
      <ul>
        <li><a href="#" class="active">Home</a></li>
        <li><a href="#">Nosotros</a></li>
        <li><a href="#">Servicios</a></li>
        <li><a href="#">Proyectos</a></li>
        <li><a href="#">Blog</a></li>
        <li><a href="#">Contacto</a></li>
      </ul>
      <div class="cl">&nbsp;</div>
    </div>
    <div class="slider">
      <div class="slider-nav"> <a href="#" class="left notext">1</a> <a href="#" class="left notext">2</a> <a href="#" class="left notext">3</a> <a href="#" class="left notext">4</a>
        <div class="cl">&nbsp;</div>
      </div>
      <ul>
        <li>
          <div class="item">
            <div class="text">
              <h3><em>Muestra tus</em></h3>
              <h2><em>IMAGENES</em></h2>
            </div>
            <?= $this->Html->image('corpN004/slider01.gif') ?> </div>
        </li>
        <li>
          <div class="item">
            <div class="text">
              <h3><em>Muestra tus</em></h3>
              <h2><em>IMAGENES</em></h2>
            </div>
            <?= $this->Html->image('corpN004/slider01.gif') ?> </div>
        </li>
        <li>
          <div class="item">
            <div class="text">
              <h3><em>Muestra tus</em></h3>
              <h2><em>IMAGENES</em></h2>
            </div>
            <?= $this->Html->image('corpN004/slider01.gif') ?> </div>
        </li>
        <li>
          <div class="item">
            <div class="text">
              <h3><em>Muestra tus</em></h3>
              <h2><em>IMAGENES</em></h2>
            </div>
            <?= $this->Html->image('corpN004/slider01.gif') ?> </div>
        </li>
      </ul>
    </div>
    <div id="main">
      <div id="content" class="left">
        <div class="highlight">
          <h3>Texto bienvenida</h3>
          <?= $this->Html->image('corpN004/highlight.gif', ['class'=>'right']) ?>
          <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
          <a href="#" class="more">Ver más</a> </div>
        <div class="projects">
          <h3>Últimos proyectos</h3>
          <div class="item">
            <div class="image left"> <a href="#"><?= $this->Html->image('corpN004/project01.jpg') ?></a> </div>
            <div class="text left">
              <h4>Titulo</h4>
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Lorem Ipsum is</p>
              <a href="#" class="more">Ver más</a> </div>
            <div class="cl">&nbsp;</div>
          </div>
          <div class="item">
            <div class="image left"> <a href="#"><?= $this->Html->image('corpN004/project02.jpg') ?></a> </div>
            <div class="text left">
              <h4>Titulo</h4>
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Lorem Ipsum is</p>
              <a href="#" class="more">Ver más</a> </div>
            <div class="cl">&nbsp;</div>
          </div>
          <div class="item">
            <div class="image left"> <a href="#"><?= $this->Html->image('corpN004/project03.jpg') ?></a> </div>
            <div class="text left">
              <h4>Titulo</h4>
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Lorem Ipsum is</p>
              <a href="#" class="more">Ver más</a> </div>
            <div class="cl">&nbsp;</div>
          </div>
          <div class="item">
            <div class="image left"> <a href="#"><?= $this->Html->image('corpN004/project04.jpg') ?></a> </div>
            <div class="text left">
              <h4>Titulo</h4>
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Lorem Ipsum is</p>
              <a href="#" class="more">Ver más</a> </div>
            <div class="cl">&nbsp;</div>
          </div>
        </div>
      </div>
      <div id="sidebar" class="right">
        <h3>Links</h3>
        <div class="sidebar-nav">
          <ul>
            <li><a href="#">Lorem Ipsum</a></li>
            <li><a href="#">Lorem Ipsum</a></li>
            <li><a href="#">Lorem Ipsum</a></li>
            <li><a href="#">Lorem Ipsum</a></li>
            <li><a href="#">Lorem Ipsum</a></li>
          </ul>
        </div>
        <a href="#" class="btn-buy"><em>Contactanos!</em></a>
        <div class="advertisement">
          <h3>Avisos</h3>
          <div class="ads">
            <div class="ad left"> <a href="#"><?= $this->Html->image('corpN004/ad02.gif') ?></a> </div>
            <div class="ad right"> <a href="#"><?= $this->Html->image('corpN004/ad02.gif') ?></a> </div>
            <div class="cl">&nbsp;</div>
          </div>
        </div>
        <div class="info">
          <h3>Titulo</h3>
          <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of</p>
        </div>
      </div>
      <div class="cl">&nbsp;</div>
    </div>
    <div class="shadow-l"></div>
    <div class="shadow-r"></div>
    <div class="shadow-b"></div>
  </div>
  <div id="footer">
    <div class="cl"></div>
  </div>
</div>
</body>
</html>