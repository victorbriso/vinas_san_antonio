<!DOCTYPE html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width">
        <?= $this->Html->css('corpN002/bootstrap') ?>
        <?= $this->Html->css('corpN002/bootstrap-responsive') ?>
        <?= $this->Html->css('corpN002/custom-styles') ?>
        <?= $this->Html->css('corpN002/font-awesome') ?>
        <?= $this->Html->css('corpN002/component') ?>
        <?= $this->Html->css('corpN002/font-awesome-ie7') ?>

        <?= $this->Html->script('corpN002/jquery-1.9.1.js') ?>
        <?= $this->Html->script('corpN002/bootstrap.js') ?>
        <?= $this->Html->script('corpN002/masonry.pkgd.min.js') ?>
        <?= $this->Html->script('corpN002/imagesloaded.js') ?>
        <?= $this->Html->script('corpN002/classie.js') ?>
        <?= $this->Html->script('corpN002/AnimOnScroll.js') ?>
        <?= $this->Html->script('corpN002/modernizr-2.6.2-respond-1.1.0.min.js') ?>
        <?= $this->fetch('css') ?>
        <?= $this->fetch('script') ?>
    </head>
    <body>
        <div class="header-wrapper">
            <div class="container">
                <div class="logo">
                    <h1>Nombre</h1>
                </div>
            <div class="menu">
                <div class="navbar">
                        <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                            <i class="fw-icon-th-list"></i>
                        </a>
                        <div class="nav-collapse collapse">
                            <ul class="nav">
                                <li><a href="#">Home</a></li>
                                <li><a href="#">Nosotros</a></li>
                                <li><a href="#">Sertvicios</a></li>
                                <li>
                                    <div class="site-name">
                                        <h1>Nombre</h1>
                                    </div>
                                </li>
                                <li><a href="#">Proyectos</a></li>
                                <li><a href="#">Blog</a></li>
                                <li><a href="#">Contacto</a></li>
                            </ul>
                        </div>
                </div>
            </div>
            </div>
        </div>
        <div class="banner">
            <div class="container">
                    <div class="carousel slide" id="myCarousel">
                        <div class="carousel-inner">
                            <div class="item">
                                <div class="carousel-caption">
                                    <h2>hasellus ultrices nulla quis nibh</h2><br>
                                    <h1>Morbi in sem quis dui placerat ornare</h1>
                                    <div class="shadow"><?= $this->Html->image('corpN002/shadow.png') ?></div>
                                </div>
                                <?= $this->Html->image('corpN002/banner-image.png') ?>
                            </div>
                            <div class="item">
                                <div class="carousel-caption">
                                    <h2>hasellus ultrices nulla quis nibh</h2><br>
                                    <h1>Morbi in sem quis dui placerat ornare</h1>
                                    <div class="shadow"><?= $this->Html->image('corpN002/shadow.png') ?></div>
                                </div>
                                <?= $this->Html->image('corpN002/banner-image.png') ?>
                            </div>
                            <div class="item active">
                                <div class="carousel-caption">
                                    <h2>hasellus ultrices nulla quis nibh</h2><br>
                                    <h1>Morbi in sem quis dui placerat ornare</h1>
                                    <div class="shadow"><?= $this->Html->image('corpN002/shadow.png') ?></div>
                                </div>
                                <?= $this->Html->image('corpN002/banner-image.png') ?>
                            </div>
                        </div>
                        <a data-slide="prev" href="#myCarousel" class="carousel-control left"><i class="fw-icon-chevron-left"></i></a>
                        <a data-slide="next" href="#myCarousel" class="carousel-control right"><i class="fw-icon-chevron-right"></i></a>
                    </div>
                    </div>
                </div>
                <div class="featured-blocks">
                    <div class="container">
                        <div class="row-fluid">
                            <div class="span4">
                                <div class="block">
                                    <div class="icon">
                                    <i class="fw-icon-user"></i>
                                    </div>
                                    <h1>ipsum dolor sit amet</h1>
                                    <p>Pellentesque lacinia mi nisi, id auctor sem ornare sed. Vivamus vitae facilisis metus. Praesent placerat enim velit</p>
                                    <a href="#myModal" role="button" class="btn" data-toggle="modal">pop up</a>
                                </div>
                            </div>
                            <div class="span4">
                                <div class="block">
                                    <div class="icon">
                                    <i class="fw-icon-flag"></i>
                                    </div>
                                    <h1>Sed placerat leo</h1>
                                    <p>Jolentesque lacinia mi nisi, id auctor sem ornare sed. Vivamus vitae facilisis metus. Praesent placerat enim velit</p>
                                    <a href="#myModal" role="button" class="btn" data-toggle="modal">pop up</a>
                                </div>
                            </div>
                            <div class="span4">
                                <div class="block">
                                    <div class="icon">
                                    <i class="fw-icon-camera"></i>
                                    </div>
                                    <h1>Pellen tesque lacinia</h1>
                                    <p>Curinentesque lacinia mi nisi, id auctor sem ornare sed. Vivamus vitae facilisis metus. Praesent placerat enim velit</p>
                                    <a href="#myModal" role="button" class="btn" data-toggle="modal">pop up</a>
                                </div>
                            </div>
                        </div>
                        <div class="row-fluid">
                            <div id="myModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                      <h2>Pellen tesque lacinia</h2>
                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed mattis sed mauris a accumsan. Phasellus quis scelerisque lacus. Aenean nec orci sit amet justo interdum ullamcorper eget eu diam. Integer dictum sem eu adipiscing cursus. Suspendisse posuere dui eu dignissim fermentum. .</p>
                      <p>Phasellus adipiscing porttitor metus, eget commodo mi. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec ut hendrerit ante. Phasellus viverra ligula tortor, ut sodales elit tempus eu. Vestibulum mattis sed purus at laoreet. Proin mattis, ante vel adipiscing porttitor, orci elit venenatis nibh, at molestie tortor dolor sit amet urna.  .</p>
                    </div>
                        </div>
                    </div>
                </div>
                <div class="featured-heading">
                    <div class="container">
                        <ul class="grid effect-8" id="grid">
                            <li><h1>Integer vitae est viverra elementum</h1>
                        <h2>Integer luctus vestibulum orci velpo</h2></li>
                        </ul>
                        
                        <div class="h-divider">
                            <div class="icon1"><i class="fw-icon-star"></i></div>
                        </div>
                        <div class="row-fluid">
                            <ul class="grid effect-3" id="grid">
                                <li class="span6">
                                    <div class="block">
                            <?= $this->Html->image('corpN002/img1.png') ?>
                            <h1>ipsum dolor sit amet</h1>
                            <p>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Suspendisse auctor urna id justo adipiscing, vel egestas sem scelerisque. Sed sed nulla dignissim magna ultricies scelerisque. Duis suscipit tellus nisi, gravida hendrerit nisi feugiat vitae faliclisis metus placerat enim.</p>
                            <a href="#" class="btn">More</a>
                        </div>
                                </li>
                                <li class="span6">
                                    <div class="block">
                            <?= $this->Html->image('corpN002/img2.png') ?>
                            <h1>Vivamul dolorem inputions quinto</h1>
                            <p>Jolem aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Suspendisse auctor urna id justo adipiscing, vel egestas sem scelerisque. Sed sed nulla dignissim magna ultricies scelerisque. Duis suscipit tellus nisi, gravida hendrerit nisi feugiat vitae faliclisis metus placerat enim.</p>
                            <a href="#" class="btn">More</a>
                        </div>
                                </li>
                            </ul>
                            
                        </div>
                    </div>
                </div>
                <div class="featured-images">
                    <div class="container">
                        <h1>In eget augue eget mauris</h1>
                        <h2>Lorem luctus vestibulum</h2>
                        <div class="hh-divider"></div>
                        <div class="row-fluid">
                            <ul class="grid effect-3" id="grid">
                                <li class="span2">
                                    <div class="user-info">
                                        <?= $this->Html->image('corpN002/img3.png') ?>
                                        <h1>John doe</h1>
                                        <p class="last">Duis suscipit tellus nisi, gravida hendrer</p>
                                        <ul>
                                            <li><a href="#"><i class="fw-icon-facebook"></a></i></li>
                                            <li><a href="#"><i class="fw-icon-twitter"></a></i></li>
                                        </ul>
                                    </div>
                                </li>
                                <li class="span2">
                                    <div class="user-info">
                                    <?= $this->Html->image('corpN002/img4.png') ?>
                                    <h1>Amada</h1>
                                    <p class="last">Duis suscipit tellus nisi, gravida hendrer</p>
                                    <ul>
                                        <li><a href="#"><i class="fw-icon-facebook"></a></i></li>
                                        <li><a href="#"><i class="fw-icon-twitter"></a></i></li>
                                    </ul>
                                </div>
                                </li>
                                <li class="span2">
                                    <div class="user-info">
                                    <?= $this->Html->image('corpN002/img5.png') ?>
                                    <h1>Peter</h1>
                                    <p class="last">Duis suscipit tellus nisi, gravida hendrer</p>
                                    <ul>
                                        <li><a href="#"><i class="fw-icon-facebook"></a></i></li>
                                        <li><a href="#"><i class="fw-icon-twitter"></a></i></li>
                                    </ul>
                                </div>
                                </li>
                                <li class="span2">
                                    <div class="user-info">
                                    <?= $this->Html->image('corpN002/img6.png') ?>
                                    <h1>Kate</h1>
                                    <p class="last">Duis suscipit tellus nisi, gravida hendrer</p>
                                    <ul>
                                        <li><a href="#"><i class="fw-icon-facebook"></a></i></li>
                                        <li><a href="#"><i class="fw-icon-twitter"></a></i></li>
                                    </ul>
                                </div>
                                </li>
                                <li class="span2">
                                    <div class="user-info">
                                    <?= $this->Html->image('corpN002/img7.png') ?>
                                    <h1>Johny</h1>
                                    <p class="last">Duis suscipit tellus nisi, gravida hendrer</p>
                                    <ul>
                                        <li><a href="#"><i class="fw-icon-facebook"></a></i></li>
                                        <li><a href="#"><i class="fw-icon-twitter"></a></i></li>
                                    </ul>
                                </div>
                                </li>
                                <li class="span2">
                                    <div class="user-info">
                                    <?= $this->Html->image('corpN002/img8.png') ?>
                                    <h1>winslet</h1>
                                    <p class="last">Duis suscipit tellus nisi, gravida hendrer</p>
                                    <ul>
                                        <li><a href="#"><i class="fw-icon-facebook"></a></i></li>
                                        <li><a href="#"><i class="fw-icon-twitter"></a></i></li>
                                    </ul>
                                </div>
                                </li>
                            </ul>
                            
                        </div>
                    </div>
                </div>
                <div class="footer-wrapper">
                    <div class="container">
                        <div class="site-footer">
                            <div class="row-fluid">
                                <div class="span3">
                                    <div class="block">
                                        <h1>ipsum dolor</h1>
                                        <ul>
                                            <li><a href="#">Duis suscipit tellus nisigra</a></li>
                                            <li><a href="#">Lorem ipsum dolor sit </a></li>
                                            <li><a href="#">Cras elementum justo sed</a></li>
                                            <li><a href="#">Sed in nulla a quam </a></li>
                                            <li><a href="#">Donec a sem vehicula</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="span3">
                                    <div class="block">
                                        <h1>Aenean eteros</h1>
                                        <ul>
                                            <li><a href="#">Cuis suscipit tellus nisigra</a></li>
                                            <li><a href="#">Korem ipsum dolor sit </a></li>
                                            <li><a href="#">Dras elementum justo sed</a></li>
                                            <li><a href="#">Eed in nulla a quam </a></li>
                                            <li><a href="#">Fonec a sem vehicula</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="span3">
                                    <div class="block">
                                        <h1>Nulla nonmi</h1>
                                        <ul>
                                            <li><a href="#">Luis suscipit tellus nisigra</a></li>
                                            <li><a href="#">Oorem ipsum dolor sit </a></li>
                                            <li><a href="#">Uras elementum justo sed</a></li>
                                            <li><a href="#">Ted in nulla a quam </a></li>
                                            <li><a href="#">Nonec a sem vehicula</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="span3">
                                    <div class="block">
                                        <h1>Phasellus cons</h1>
                                        <ul>
                                            <li>
                                                
                                                    <i class="fw-icon-mobile-phone icon2"></i>
                                                
                                                <div class="info">
                                                <span>Call Us</span><br><a href="#">(000) 7777 77777</a>
                                                </div>
                                            </li>
                                            <li>
                                                
                                                    <i class="fw-icon-envelope-alt icon2"></i>
                                                
                                                <div class="info">
                                                <span>Mail Us</span><br><a href="#">info@companyname.com</a>
                                                </div>
                                            </li>
                                            
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="copy-rights">
                        </div>
                    </div>
                </div>
        

        
    
    
    <script>
      new AnimOnScroll( document.getElementById( 'grid' ), {
        minDuration : 0.4,
        maxDuration : 0.7,
        viewportFactor : 0.2
      } );
    </script>
<script>
$('#myCarousel').carousel({
    interval: 1800
});
</script>

    </body>
</html>
