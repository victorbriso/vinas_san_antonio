<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <title>Architect Group</title>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <?= $this->Html->css('corpN001/style') ?>
  </head>
  <body>
    <div id="container">
      <div class="headerzone">
        <div class="logozone"> <a href="#"><?= $this->Html->image('corpN001/logo.jpg') ?></a> </div>
        <div class="clear"></div>
      </div>
      <div class="clear"></div>
      <div class="mainmenu">
        <?= $this->element('corpN001/menu'); ?>
      </div>
      <div class="clear"></div>
      <div class="banner"><?= $this->Html->image('corpN001/banner.jpg') ?></div>
      <div class="clear"></div>
      <div class="workzone">
      <div class="workzone-left">
      <div>
      <div>
      <h1>Lo<span class="redheading">Nuevo</span></h1>
      </div>
      <div>
      <div class="grayboldtxt">Aliquam non | <span class="bluelighttxt">22.05.2009</span></div>
      <div class="newcontent"> In nec tellus congue libero ultricies molestie. Duis et diam. Suspendisse interdum velit eget pede. Duis facilisis dignissim urna. </div>
      </div>
      <div>
      <div class="grayboldtxt">Sollicitudin velit | <span class="bluelighttxt">24.05.2009</span></div>
      <div class="newcontent"> Vestibulum convallis metus eget orci posuere bibendum. Quisque sit amet augue.Nam magna. Pellentesque vitae velit at dui semper sodales. Curabitur accumsan libero. </div>
      </div>
      <div>
      <div class="grayboldtxt">Sollicitudin velit | <span class="bluelighttxt">27.05.2009</span></div>
      <div class="newcontent"> In nec tellus congue libero ultricies molestie. Duis et diam. Suspendisse interdum velit eget pede. Duis facilisis dignissim urna. Proin eu velit. Donec blandit, orci id dapibus pretium, metus ante pulvinar nunc, ac vestibulum nisi metus nec nisl. </div>
      </div>
      <div class="more" align="right"><a href="#">Más Noticias</a></div>
      </div>
      <div class="clear"></div>
      <div style="padding:20px 0px 0px 0px;">
      <div>
      <h1>Nuestros <span class="redheading">Servicios</span></h1>
      </div>
      <div class="service">
      <ul>
      <li><a href="#">Sed gravida erat in sapien.</a></li>
      <li><a href="#">Morbi fermentum urna vel risus.</a></li>
      <li><a href="#">Proin ac ligula at mi laoreet mattis.</a></li>
      <li><a href="#">Sed volutpat ipsum quis nisi.</a></li>
      <li><a href="#">Maecenas accumsan pretium augue.</a></li>
      <li><a href="#">Maecenas feugiat mi nec metus.</a></li>
      </ul>
      </div>
      </div>
      <div class="clear"></div>
      </div>
      <div class="workzone-right">
      <div>
      <div>
      <div>
      <h1>Bienvenido a <span class="redheading">Architect Group</span></h1>
      </div>
      <div class="welcomezone"><?= $this->Html->image('corpN001/welcome-img.jpg', ['class'=>'welcomeimg']) ?> Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Duis cursus tortor. Nunc consectetuer diam ac odio. Pellentesque vel mauris sit amet urna malesuada ornare. Curabitur venenatis est eget arcu. Donec vestibulum. Proin rutrum. Morbi commodo fringilla orci. Ut vel tortor. In ut velit. Vivamus hendrerit aliquam quam. Curabitur placerat eros vitae libero. Fusce sagittis commodo purus. Cras orci. Quisque at justo. Quisque ullamcorper feugiat ligula. Quisque vulputate.<br />
      <br />
      Pellentesque vitae velit at dui semper sodales. Curabitur accumsan ornare libero. Quisque auctor. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nulla adipiscing porta ante.
      <div class="clear"></div>
      </div>
      </div>
      <div class="clear"></div>
      <div>
      <div>
      <h1>Proyectos <span class="redheading">en marcha</span></h1>
      </div>
      <div style="padding-top:20px;">
      <div class="column1">
      <div>
      <div class="grayboldtxt">Suspendisse interdum velit dignissim | <span class="redlighttxt">12.05.2009</span> </div>
      <div class="projectimg"><?= $this->Html->image('corpN001/project1.jpg') ?></div>
      <div>
      <div>
      <h2>Aenean nibh imperdiet</h2>
      <div class="borderbottom"> Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nulla adipiscing porta ante. Morbi vitae turpis sed tellus dapibus placerat. Lorem ipsum dolor sit amet.</div>
      </div>
      <div class="clear"></div>
      <div>
      <h2>Duis et diam</h2>
      <div> Fusce tristique, nisl vel gravida venenatis, risus magna eleifend pede, id bibendum mauris metus et erat. Morbi in leo. Quisque sollicitudin sagittis est.</div>
      </div>
      </div>
      </div>
      </div>
      <div class="column2">
      <div>
      <div class="grayboldtxt">Nunc accumsan interdum <br />
      tristique | <span class="redlighttxt">15.05.2009</span> </div>
      <div class="projectimg"><?= $this->Html->image('corpN001/project2.jpg') ?></div>
      <div>
      <div>
      <h2>Volutpat dignissim</h2>
      <div class="borderbottom"> Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nulla adipiscing porta ante. Morbi vitae turpis sed tellus dapibus placerat. Lorem ipsum dolor sit amet.</div>
      </div>
      <div class="clear"></div>
      <div>
      <h2>Faucibus orci luctus</h2>
      <div> Fusce tristique, nisl vel gravida venenatis, risus magna eleifend pede, id bibendum mauris metus et erat. Morbi in leo. Quisque sollicitudin sagittis est.</div>
      </div>
      </div>
      </div>
      </div>
      <div class="column3">
      <div>
      <div class="grayboldtxt">Nunc accumsan interdum <br />
      tristique | <span class="redlighttxt">15.05.2009</span> </div>
      <div class="projectimg"><?= $this->Html->image('corpN001/project3.jpg') ?></div>
      <div>
      <div>
      <h2>Nulla adipiscing porta</h2>
      <div class="borderbottom"> Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nulla adipiscing porta ante. Morbi vitae turpis sed tellus dapibus placerat. Lorem ipsum dolor sit amet.</div>
      </div>
      <div class="clear"></div>
      <div>
      <h2>Vivamus hendrerit aliquam</h2>
      <div> Fusce tristique, nisl vel gravida venenatis, risus magna eleifend pede, id bibendum mauris metus et erat. Morbi in leo. Quisque sollicitudin sagittis est.</div>
      </div>
      </div>
      </div>
      </div>
      <div class="clear"></div>
      </div>
      </div>
      <div class="clear"></div>
      </div>
      </div>
      <div class="clear"></div>
      </div>
      <div class="clear"></div>
    </div>
    <div class="clear"></div>
    <div class="footer">
    <div class="footerlink"> </div>
    </div>
    <div class="clear"></div>
  </body>
</html>