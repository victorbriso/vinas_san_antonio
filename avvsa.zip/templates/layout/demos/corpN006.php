<!DOCTYPE HTML>
<head>
<title>Blueline Media</title>
<meta charset="utf-8">
<!-- Google Fonts -->
<link href='https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300|Playfair+Display:400italic' rel='stylesheet' type='text/css' />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
<!-- CSS Files -->

<?= $this->Html->css('corpN006/style') ?>
<?= $this->Html->css('corpN006/simple_menu') ?>
<?= $this->Html->script('corpN006/jquery.tools.min.js') ?>
<?= $this->fetch('css') ?>
<?= $this->fetch('script') ?>
<script>
$(function () {
    $("#prod_nav ul").tabs("#panes > div", {
        effect: 'fade',
        fadeOutSpeed: 400
    });
});
</script>
<script>
$(document).ready(function () {
    $(".pane-list li").click(function () {
        window.location = $(this).find("a").attr("href");
        return false;
    });
});
</script>
</head>
<body>
<div class="header">
  <div id="site_title"><a href="index.html"><?= $this->Html->image('corpN006/logo.png') ?></a></div>
  <!-- Main Menu -->
  <ol id="menu">
    <li class="active_menu_item"><a href="index.html">Home</a>
      <!-- sub menu -->
      <ol>
        <li><a href="#">Nivo Slider</a></li>
        <li><a href="#">EI Slider</a></li>
        <li><a href="#">Fullscreen Slider</a></li>
        <li><a href="#">Static Image</a></li>
      </ol>
    </li>
    <!-- END sub menu -->
    <li><a href="#">Pages</a>
      <!-- sub menu -->
      <ol>
        <li><a href="#">Magazine</a></li>
        <li><a href="#">Blog</a></li>
        <li><a href="#">Full Width Page</a></li>
        <li><a href="#">Columns</a></li>
      </ol>
    </li>
    <!-- END sub menu -->
    <li><a href="#">Elements</a></li>
    <li><a href="#">Galleries</a>
      <!-- sub menu -->
      <ol>
        <li><a href="#">Simple</a></li>
        <li><a href="#">Filterable</a></li>
        <li><a href="#">Fade Scroll</a></li>
        <li><a href="#">Video</a></li>
        <li class="last"><a href="#">PhotoGrid</a></li>
      </ol>
    </li>
    <!-- END sub menu -->
    <li><a href="#">Contact</a></li>
  </ol>
</div>
<!-- END header -->
<div id="container">
  <!-- tab panes -->
  <div id="prod_wrapper">
    <div id="panes">
      <div> <?= $this->Html->image('corpN006/demo/1.jpg') ?>
        <h1>Welcome to our site</h1>
        <p>Nulla hendrerit commodo tortor, vitae elementum magna convallis nec. Nam tempor nibh a purus aliquam et adipiscing elit gravida. Ut vitae nunc a libero volutpat gravida. Nullam egestas mi sit amet dui scelerisque eu laoreet nisi ultrices. Ut vitae nunc a libero volutpat gravida. Nam tempor nibh a purus aliquam. </p>
        <p style="text-align:right; margin-right: 16px"><a href="#" class="button">More Info</a> <a href="#" class="button">Buy Now</a></p>
      </div>
      <div> <?= $this->Html->image('corpN006/demo/2.jpg') ?>
        <h2>Meet Our Team</h2>
        <p>Nulla hendrerit commodo tortor, vitae elementum magna convallis nec. Nam tempor nibh a purus aliquam et adipiscing elit gravida. Ut vitae nunc a libero volutpat gravida. Nullam egestas mi sit amet dui scelerisque eu laoreet nisi ultrices. Ut vitae nunc a libero volutpat gravida. Nam tempor nibh a purus aliquam. </p>
        <p style="text-align:right; margin-right: 16px"><a href="#" class="button">More Info</a> <a href="#" class="button">Buy Now</a></p>
      </div>
      <div> <?= $this->Html->image('corpN006/demo/3.jpg') ?>
        <h2>Mauris elementum</h2>
        <p>Nulla hendrerit commodo tortor, vitae elementum magna convallis nec. Nam tempor nibh a purus aliquam et adipiscing elit gravida. Ut vitae nunc a libero volutpat gravida. Nullam egestas mi sit amet dui scelerisque eu laoreet nisi ultrices. Ut vitae nunc a libero volutpat gravida. Nam tempor nibh a purus aliquam. </p>
        <p style="text-align:right; margin-right: 16px"><a href="#" class="button">More Info</a> <a href="#" class="button">Buy Now</a></p>
      </div>
      <div> <?= $this->Html->image('corpN006/demo/4.jpg') ?>
        <h2>Nam tempor nibh</h2>
        <p>Nulla hendrerit commodo tortor, vitae elementum magna convallis nec. Nam tempor nibh a purus aliquam et adipiscing elit gravida. Ut vitae nunc a libero volutpat gravida. Nullam egestas mi sit amet dui scelerisque eu laoreet nisi ultrices. Ut vitae nunc a libero volutpat gravida. Nam tempor nibh a purus aliquam. </p>
        <p style="text-align:right; margin-right: 16px"><a href="#" class="button">More Info</a> <a href="#" class="button">Buy Now</a></p>
      </div>
      <div> <?= $this->Html->image('corpN006/demo/5.jpg') ?>
        <h2>Supercar</h2>
        <p>Nulla hendrerit commodo tortor, vitae elementum magna convallis nec. Nam tempor nibh a purus aliquam et adipiscing elit gravida. Ut vitae nunc a libero volutpat gravida. Nullam egestas mi sit amet dui scelerisque eu laoreet nisi ultrices. Ut vitae nunc a libero volutpat gravida. Nam tempor nibh a purus aliquam. </p>
        <p style="text-align:right; margin-right: 16px"><a href="#" class="button">More Info</a> <a href="#" class="button">Buy Now</a></p>
      </div>
    </div>
    <!-- END tab panes -->
    <div style="clear:both"></div>
    <!-- navigator -->
    <div id="prod_nav">
      <ul>
        <li><a href="#1"><?= $this->Html->image('corpN006/demo/1.jpg', ['width'=>160]) ?><strong>Class aptent</strong> $ 199</a></li>
        <li><a href="#2"><?= $this->Html->image('corpN006/demo/2.jpg', ['width'=>160]) ?><strong>Sed dui risus</strong> $ 125</a></li>
        <li><a href="#3"><?= $this->Html->image('corpN006/demo/3.jpg', ['width'=>160]) ?><strong>Pellentesque quis</strong> $ 480</a></li>
        <li><a href="#4"><?= $this->Html->image('corpN006/demo/4.jpg', ['width'=>160]) ?><strong>Mauris elementum</strong> $ 1099</a></li>
        <li><a href="#5"><?= $this->Html->image('corpN006/demo/5.jpg', ['width'=>160]) ?><strong>Cras et malesuada</strong> $ 99</a></li>
      </ul>
    </div>
    <!-- END navigator -->
  </div>
  <!-- END prod wrapper -->
  <div style="clear:both"></div>
  <div class="one-third">
    <h2>Business Solutions</h2>
    <p>Nulla hendrerit commodo tortor, vitae elementum magna convallis nec. Nam tempor nibh a purus aliquam et adipiscing elit gravida.</p>
    <p style="text-align:right; margin-right: 15px"><a href="#" class="button_small">Find out more</a></p>
  </div>
  <div class="one-third">
    <h2>Become a Partner</h2>
    <p>Nulla hendrerit commodo tortor, vitae elementum magna convallis nec. Nam tempor nibh a purus aliquam et adipiscing elit gravida.</p>
    <p style="text-align:right; margin-right: 15px"><a href="#" class="button_small">Contact Us Today</a></p>
  </div>
  <div class="one-third last">
    <h2>Latest News</h2>
    <p>Nulla hendrerit commodo tortor, vitae elementum magna convallis nec. Nam tempor nibh a purus aliquam et adipiscing elit gravida.</p>
    <p style="text-align:right; margin-right: 15px"><a href="#" class="button_small">Read Article</a></p>
  </div>
  <div style="clear:both"></div>
  <div class="box_highlight" style="margin-top:40px">
    <h2 style="text-align:center">Some kind of sales pitch goes here!</h2>
  </div>
  <div style="clear:both; height: 20px"></div>
</div>
<!-- END container -->
<div id="footer">
  <!-- First Column -->
  <div class="one-fourth">
    <h3>Useful Links</h3>
    <ul class="footer_links">
      <li><a href="#">Lorem Ipsum</a></li>
      <li><a href="#">Ellem Ciet</a></li>
      <li><a href="#">Currivitas</a></li>
      <li><a href="#">Salim Aritu</a></li>
    </ul>
  </div>
  <!-- Second Column -->
  <div class="one-fourth">
    <h3>Terms</h3>
    <ul class="footer_links">
      <li><a href="#">Lorem Ipsum</a></li>
      <li><a href="#">Ellem Ciet</a></li>
      <li><a href="#">Currivitas</a></li>
      <li><a href="#">Salim Aritu</a></li>
    </ul>
  </div>
  <!-- Third Column -->
  <div class="one-fourth">
    <h3>Information</h3>
    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent sit amet enim id dui tincidunt vestibulum rhoncus a felis.
  </div>
  <!-- Fourth Column -->
  <div class="one-fourth last">
    <h3>Socialize</h3>
    <?= $this->Html->image('corpN006/icon_fb.png') ?>
    <?= $this->Html->image('corpN006/icon_twitter.png') ?>
    <?= $this->Html->image('corpN006/icon_in.png') ?>
</div>
  <div style="clear:both"></div>
</div>
<!-- END footer -->
</body>
</html>