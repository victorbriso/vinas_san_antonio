<div class="col-md-12"  style="width: 100% !important">
    <div class="col-md-12"> 
        <h4 class="text-center"><?=$titulo?></h4>                 
        <div class="row">            
            <? foreach ($vinas as $key => $value) {
                $img=(file_exists('img/logos/vinas/'.$value['id'].'.'.$value['ext'])?'logos/vinas/'.$value['id'].'.'.$value['ext']:'logos/avvsa.png');
            ?>
                <div class="col-md-12" style="padding: 10px;">
                    <div class="row">
                        <div class="col-md-4">
                            <?= $this->Html->image($img, array('class'=>'img-fluid rounded mx-auto d-block', 'style'=>'max-height:150px;')) ?>
                        </div>
                        <div class="col-md-8">
                            <h4 class="text-center"><?=$value['nombre']?></h4>
                        </div>
                        <div class="col-md-12 text-center">
                            <?= $this->html->link('Visita la web', ['action'=>'servicios']) ?>
                        </div>
                    </div>
                </div>
           <? } ?>
        </div>                    
    </div>
</div>