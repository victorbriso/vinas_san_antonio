<div class="col-md-12">
    <div class="row">
        <div class="col-md-12">
            <h4 class="text-center"><?= $titulo?></h4>
        </div>
        <div class="col-md-12">
            espacio imagen
        </div>
        <? foreach ($texto as $key => $value) { ?>
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-4">
                        espacio imagen
                    </div>
                    <div class="col-md-8">
                        <div class="col-md-12">
                            <h4 class="text-center"><?= $value['titulo']?></h4>
                        </div>
                        <div class="col-md-12">
                            <p><? if(!is_array($value['contenido'])){echo $value['contenido'];} ?></p>
                            <? if(isset($value['extras'])){
                                foreach ($value['extras'] as $key1 => $value1) { ?>
                                    <ul>
                                        <li>
                                            <?= $value1['subTitulo']?>
                                        </li>
                                        <ul>
                                            <li>
                                                <?= $value1['bajada']?>
                                            </li>
                                        </ul>
                                    </ul> 
                                <?}
                            } ?>
                            <? if(isset($value['lista'])){
                                $varLista=explode('-', $value['lista']);
                                ?><ul><?
                                foreach ($varLista as $key2 => $value2) {?>
                                    <li><?= $value2?></li>
                                <?}?>
                                </ul>
                            <?} ?>
                        </div>
                    </div>
                </div>
            </div>
        <?} ?>
        
    </div>
</div>