<div class="col-md-12">
    <h4 class="text-center"><?=$titulo?></h4>
    <div class="row">
        <div class="col-md-4 offset-md-4 text-center">
            <ul class="text-left">
                <? foreach ($requisitos as $key => $value) {?>
                    <li><?= $value['requisito_'.$lang] ?></li>
                <?} ?>    
            </ul>
            <?= $this->html->link($bajada, ['action'=>'contacto'], ['class'=>'text-center']) ?> 
        </div>
        
        
    </div>
</div>