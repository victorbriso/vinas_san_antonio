<div class="col-md-12">
    <div class="row">
        <div class="col-md-12">
            <h4 class="text-center"><?= $titulo?></h4>
        </div>
        <div class="col-md-12">
            espacio imagen
        </div>
        <? foreach ($texto as $key => $value) { ?>
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-4">
                        espacio imagen
                    </div>
                    <div class="col-md-8">
                        <div class="col-md-12">
                            <h4 class="text-center"><?= $value['titulo']?></h4>
                        </div>
                        <div class="col-md-12">
                            <p><?= $value['contenido']?></p>
                        </div>
                    </div>
                </div>
            </div>
        <?} ?>
        
    </div>
</div>