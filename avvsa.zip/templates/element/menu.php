<div class="row">
    <div class="col-10 col-sm-10 col-md-3">
        <?= $this->Html->image('logos/avvsa.png', array('class'=>'img-fluid rounded mx-auto d-block', 'style'=>'width:100%;')) ?>
    </div>
    <div class="col-2 col-sm-2 col-md-9" style="margin-top: 30px;">
        <nav class="navbar navbar-expand-lg navbar-light ">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-0">
                    <li class="nav-item active">
                        <?= $this->html->link('Inicio', ['action'=>'index'], ['class'=>'nav-link']) ?>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Quienes Somos</a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <?= $this->html->link('Los Pioneros', ['action'=>'losPioneros'], ['class'=>'dropdown-item']) ?>
                            <?= $this->html->link('AVVSA', ['action'=>'avvsa'], ['class'=>'dropdown-item']) ?>
                            <?= $this->html->link('Viñas', ['action'=>'vinas'], ['class'=>'dropdown-item']) ?>
                            <?= $this->html->link('La Organización', ['action'=>'organizacion'], ['class'=>'dropdown-item']) ?>
                            <?= $this->html->link('Código de etica', ['action'=>'codigoEtica'], ['class'=>'dropdown-item']) ?>
                            <?= $this->html->link('Asociarse a AVVSA', ['action'=>'asociarseAvvsa'], ['class'=>'dropdown-item']) ?>
                        </div>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">El Valle de San Antonio</a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <?= $this->html->link('Terroir', ['action'=>'terroir'], ['class'=>'dropdown-item']) ?>
                            <?= $this->html->link('Cepas', ['action'=>'cepas'], ['class'=>'dropdown-item']) ?>
                            <!--<?= $this->html->link('El Valle en cifras', ['action'=>'valleEnCifras'], ['class'=>'dropdown-item']) ?>-->
                            <?= $this->html->link('Los enólogos y viticultores', ['action'=>'enologosViticultores'], ['class'=>'dropdown-item']) ?>
                            <?= $this->html->link('Mapa físico', ['action'=>'mapaFisico'], ['class'=>'dropdown-item']) ?>
                            <?= $this->html->link('Mapa Turístico', ['action'=>'mapaTuristico'], ['class'=>'dropdown-item']) ?>
                        </div>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Actualidad</a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <?= $this->html->link('Noticias', ['action'=>'noticias'], ['class'=>'dropdown-item']) ?>
                            <?= $this->html->link('Eventos', ['action'=>'eventos'], ['class'=>'dropdown-item']) ?>
                        </div>
                    </li>
                    <li class="nav-item">
                        <?= $this->html->link('Sustentabilidad', ['action'=>'sustentabilidad'], ['class'=>'nav-link']) ?>
                    </li>
                    <li class="nav-item">
                        <?= $this->html->link('Contacto', ['action'=>'contacto'], ['class'=>'nav-link']) ?>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Idioma</a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown" style="max-width:60px !important">
                            <button class="btn btn-vacio dropdown-item" id="es" onclick="cambiaIdioma(this)" token=<?=$token?>>
                                <?=$this->Html->image('banderas/espana.jpg', array('class'=>'bandera-idioma'))?>
                            </button>
                            <button class="btn btn-vacio dropdown-item" id="en" onclick="cambiaIdioma(this)" token=<?=$token?>>
                                <?=$this->Html->image('banderas/inglaterra.png', array('class'=>'bandera-idioma'))?>
                            </button>
                            <button class="btn btn-vacio dropdown-item" id="br" onclick="cambiaIdioma(this)" token=<?=$token?>>
                                <?=$this->Html->image('banderas/brasil.png', array('class'=>'bandera-idioma'))?>
                            </button>                            
                        </div>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</div>
<div class="d-none">
    <form id="ajaxForm">
        <input type="hidden" name="_Token[fields]" autocomplete="off" value="<?=$token?>">
        <input type="hidden" name="idioma" autocomplete="off" value="es" id="langInput">
    </form>
</div>
<script type="text/javascript">
    function cambiaIdioma(data){        
        var nuevoIdioma=data.id;
        $('#langInput').val(nuevoIdioma);
        var token= $(data).attr('token');
        var ajaxdata = $("#ajaxForm").serializeArray();
        console.log(ajaxdata);
        setTimeout(function(){
            $.ajax({
                type: 'POST',
                url: 'cambiaIdioma',
                headers: { 'X-XSRF-TOKEN' : token },
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('X-CSRF-Token', token);
                },
                data: ajaxdata,
                success: function (result) {
                    console.log(result);
                    respuesta=JSON.parse(result);
                    if(respuesta.res==2){
                        location.reload();
                    }else if(respuesta.res==1){
                        alert('error al cambiar el idioma\nlanguage change error\nerro de mudança de idioma');
                    }
                },
                error: function (result){
                    console.log(result);
                    alert('error al cambiar el idioma\nlanguage change error\nerro de mudança de idioma');
                }
            });     
        }, 500);
        
    }
</script>