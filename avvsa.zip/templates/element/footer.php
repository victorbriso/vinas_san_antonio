<div class="col-md-12 suscripcion">
    <div class="tabla-suscripcion">
        <h4 class="titulo-suscripcion">Mantente al día con las noticias</h4>
        <form>
            <table>
                <tr>
                    <td>
                        <input type="email" name="mail" placeholder="Ingresa tu e-mail" class="form-control">
                    </td>
                    <td>
                        <button class="btn btn-info">Suscribete</button>
                    </td>
                </tr>
            </table>
        </form>
    </div>
</div>
<div class="col-md-12 footer">
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-12">
                <table>
                    <tr>
                        <td>
                            <ul class="lista-menu">
                                <li>Quienes Somos
                                    <ul>
                                        <li>Los Pioneros</li>
                                        <li>AVVSA</li>
                                        <li>Organizacion</li>
                                    </ul>
                                </li>   
                            </ul>
                        </td>
                        <td>
                            <ul class="lista-menu">
                                <li>Nuestros Socios
                                    <ul>
                                        <li>Viñas</li>
                                        <li>Asociarse a AVVSA</li>
                                    </ul>
                                </li>
                            </ul>
                        </td>
                        <td>
                            <ul class="lista-menu">
                                <li>El Valle de San Antonio
                                    <ul>
                                        <li>Terroir</li>
                                        <li>Cepas</li>
                                        <li>El Valle en cifras</li>
                                        <li>Los enólogos y viticultores</li>
                                        <li>Mapa físico</li>
                                        <li>Mapa turístico</li>
                                    </ul>
                                </li>
                            </ul>
                        </td>
                        <td>
                            <ul class="lista-menu">
                                <li>Actualidad
                                    <ul>
                                        <li>Noticias</li>
                                        <li>Eventos</li>
                                    </ul>
                                </li>
                            </ul>
                        </td>
                        <td>
                            <ul class="lista-menu">
                                <li>Sustentabilidad</li>
                            </ul>
                        </td>
                        <td>
                            <ul class="lista-menu">
                                <li>Contacto</li>
                            </ul>
                        </td>
                        <td>
                            <ul class="lista-menu">
                                <li>Idiomas
                                    <ul>
                                        <li>Español</li>
                                        <li>Ingles</li>
                                        <li>Portugues</li>
                                    </ul>
                                </li>
                            </ul>
                        </td>
                    </tr>
                </table>                    
            </div>
            <div class="col-md-12 contenido-al-cen">
                <div class="col-md-6">
                    <div class="row">                       
                        <div class="col-3 contenido-al-cen">
                            <a href="">
                                <?= $this->Html->image('banderas/facebook.png', array('class'=>'img-fluid rrss')) ?>
                            </a>                            
                        </div>
                        <div class="col-3" style="text-align: center;">
                            <a href="">
                                <?= $this->Html->image('banderas/instagram.svg', array('class'=>'img-fluid rrss')) ?>
                            </a>
                        </div>
                        <div class="col-3 contenido-al-cen">
                            <a href="">
                                <?= $this->Html->image('banderas/linkedin.svg', array('class'=>'img-fluid rrss')) ?>
                            </a>
                        </div>
                        <div class="col-3 contenido-al-cen">
                            <a href="">
                                <?= $this->Html->image('banderas/whatsapp.svg', array('class'=>'img-fluid rrss')) ?>
                            </a>
                        </div>
                    </div>      
                </div>                  
            </div>
            
        </div>
    </div>
</div>
<div class="footer2">
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-6">
                <p class="legales">Avisos legales</p>
            </div>
            <div class="col-md-6">
                <p class="vbs"><a href="https://vbstechnology.cl">Sitio desarrollado por VBS Technology</a></p>
                
            </div>
        </div>
    </div>
</div>