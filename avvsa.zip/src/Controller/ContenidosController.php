<?php
declare(strict_types=1);
namespace App\Controller;

use Cake\Core\Configure;
use Cake\Http\Exception\ForbiddenException;
use Cake\Http\Exception\NotFoundException;
use Cake\Http\Response;
use Cake\View\Exception\MissingTemplateException;
use Cake\Mailer\Mailer;
use Cake\ORM\TableRegistry;

class ContenidosController extends AppController{
    public function beforeFilter(\Cake\Event\EventInterface $event){
        parent::beforeFilter($event);
        $destino=$this->request->params['action'];
        if(!$this->request->getSession()->check('edad')){  
            $this->request->getSession()->write('destino', $destino);
            return $this->redirect(['controller'=>'Edad', 'action' => 'edad']);
        }
        //$this->Auth->allow(['cambiaIdioma']);
        $this->Security->setConfig('unlockedActions', ['cambiaIdioma']);
    }
    public function initialize(): void
    {
        parent::initialize();
        $this->loadComponent('RequestHandler');
    }
    public function display(...$path): ?Response
    {
        if (!$path) {
            return $this->redirect('/');
        }
        if (in_array('..', $path, true) || in_array('.', $path, true)) {
            throw new ForbiddenException();
        }
        $page = $subpage = null;

        if (!empty($path[0])) {
            $page = $path[0];
        }
        if (!empty($path[1])) {
            $subpage = $path[1];
        }
        $this->set(compact('page', 'subpage'));

        try {
            return $this->render(implode('/', $path));
        } catch (MissingTemplateException $exception) {
            if (Configure::read('debug')) {
                throw $exception;
            }
            throw new NotFoundException();
        }

        return $this->render();
    }
    public function index(){

    }
    public function losPioneros(){
        $idioma=$this->idioma();
        $data=$this->Contenidos->obtieneContenido($idioma, 3);
        if($data){
            $contenidos=json_decode($data[0]['contenido_'.$idioma], true);
            $titulo=$contenidos['titulo'];
            $texto=$contenidos['contenido'];
            $extencion=$data[0]['img_principal'];
            $this->set([
                'titulo' => $titulo,
                'texto'=>$texto,
                'extencion'=>$extencion
            ]);     
        }else{
            return $this->redirect(['controller'=>'Edad', 'action' => 'index']);
        }        
    }
    public function avvsa(){
        $idioma=$this->idioma();
        $data=$this->Contenidos->obtieneContenido($idioma, 1);
        if($data){
            $contenidos=json_decode($data[0]['contenido_'.$idioma], true);
            $titulo=$contenidos['titulo'];
            $texto=$contenidos['contenido'];
            $extencion=$data[0]['img_principal'];
            $this->set([
                'titulo' => $titulo,
                'texto'=>$texto,
                'extencion'=>$extencion
            ]);     
        }else{
            return $this->redirect(['controller'=>'Edad', 'action' => 'index']);
        }  
    }
    public function organizacion(){
        $idioma=$this->idioma();
        $data=$this->Contenidos->obtieneContenido($idioma, 2);
        if($data){
            $contenidos=json_decode($data[0]['contenido_'.$idioma], true);
            $titulo=$contenidos['titulo'];
            $texto=$contenidos['contenido'];
            $extencion=$data[0]['img_principal'];
            $this->set([
                'titulo' => $titulo,
                'texto'=>$texto,
                'extencion'=>$extencion
            ]);     
        }else{
            return $this->redirect(['controller'=>'Edad', 'action' => 'index']);
        }  
    }
    public function vinas(){
        $idioma=$this->idioma();
        $this->loadModel('Vinas');
        $info=$this->Vinas->obtieneVinas($idioma);
        if($idioma=='es'){
            $titulo='Las Viñas';
        }elseif ($idioma=='en') {
            $titulo='The Vineyards';
        }elseif ($idioma=='br') {
            $titulo='As Vinhas';
        }else{
            $titulo='Las Viñas';
        }
        $this->set([
            'vinas' => $info,
            'titulo'=>$titulo
        ]);      
    }
    public function asociarseAvvsa(){
        $idioma=$this->idioma();
        $this->loadModel('Requisitos');
        $requisitos=$this->Requisitos->obtieneRequisitos($idioma);
        if($idioma=='es'){
            $titulo='Asociarse a AVVSA';
            $bajada='Para más informacion, escribenos';
        }elseif ($idioma=='en') {
            $titulo='Join AVVSAs';
            $bajada='For more information, write us';
        }elseif ($idioma=='br') {
            $titulo='Associe-se à AVVSA';
            $bajada='Para mais informações, escreva-nos';
        }else{
            $titulo='Las Viñas';
            $bajada='Para más informacion, escribenos';
        }
        $this->set([
            'titulo'=>$titulo,
            'requisitos'=>$requisitos,
            'lang'=>$idioma,
            'bajada'=>$bajada
        ]);  
    }
    public function terroir(){
        $idioma=$this->idioma();
        $data=$this->Contenidos->obtieneContenido($idioma, 5);
        if($data){
            $contenidos=json_decode($data[0]['contenido_'.$idioma], true);
            $titulo=$contenidos['titulo'];
            $texto=$contenidos['contenido'];
            $extencion=$data[0]['img_principal'];
            $this->set([
                'titulo' => $titulo,
                'texto'=>$texto,
                'extencion'=>$extencion
            ]);     
        }else{
            return $this->redirect(['controller'=>'Edad', 'action' => 'index']);
        }  
    }
    public function cepas(){
        $idioma=$this->idioma();
        $data=$this->Contenidos->obtieneContenido($idioma, 4);
        if($data){
            $contenidos=json_decode($data[0]['contenido_'.$idioma], true);
            $titulo=$contenidos['titulo'];
            $texto=$contenidos['contenido'];
            $extencion=$data[0]['img_principal'];
            $this->set([
                'titulo' => $titulo,
                'texto'=>$texto,
                'extencion'=>$extencion
            ]);     
        }else{
            return $this->redirect(['controller'=>'Edad', 'action' => 'index']);
        }  
    }
    public function codigoEtica(){
        $idioma=$this->idioma();
        $data=$this->Contenidos->obtieneContenido($idioma, 6);
        if($data){
            $contenidos=json_decode($data[0]['contenido_'.$idioma], true);
            //prx($contenidos);
            $titulo=$contenidos['titulo'];
            $texto=$contenidos['contenido'];
            $extencion=$data[0]['img_principal'];
            $this->set([
                'titulo' => $titulo,
                'texto'=>$texto,
                'extencion'=>$extencion
            ]);     
        }else{
            return $this->redirect(['controller'=>'Edad', 'action' => 'index']);
        }  
    }
    public function valleEnCifras(){
        
    }
    public function enologosViticultores(){
        
    }
    public function mapaFisico(){
        
    }
    public function mapaTuristico(){
        
    }
    public function noticias(){
        
    }
    public function eventos(){
        
    }
    public function sustentabilidad(){
        
    }
    public function contacto(){
        $idioma=$this->idioma();
        if($idioma=='es'){
            $titulo='Escribenos, te contactaremos a la brevedad.';
            $nombre='Nombre';
            $asunto='Asunto';
            $fono='Teléfono';
        }elseif ($idioma=='en') {
            $titulo='Write us, we will contact you shortly.';
            $nombre='Name';
            $asunto='Affair';
            $fono='Phone';
        }elseif ($idioma=='br') {
            $titulo='Escreva-nos, entraremos em contato em breve.';
            $nombre='Nome';
            $asunto='Caso';
            $fono='Telefone';
        }else{
            $titulo='Escreva-nos, entraremos em contato em breve.';
            $nombre='Nome';
            $asunto='Caso';
            $fono='Telefone';
        }
        $this->set([
            'titulo' => $titulo,
            'nombre'=>$nombre,
            'asunto'=>$asunto,
            'fono'=>$fono
        ]);   
    }
    public function cambiaIdioma($lang=null){        
        $this->viewBuilder()->setLayout('ajax');
        $this->autoRender=false;
        $data=$this->request->getData();
        if(isset($data['idioma'])){
            $this->request->getSession()->delete('idioma');
            $this->request->getSession()->write('idioma', $data['idioma']);
            $res=2;
        }else{
            $this->request->getSession()->delete('idioma');
            $this->request->getSession()->write('idioma', 'es');
            $res=1;
        }
        $this->set(compact('res'));
        echo json_encode(compact('res'));
    }
    public function pruebas(){
        $data['titulo']='PRESENTACION';
        $data['contenido'][0]['titulo']='';
        $data['contenido'][0]['contenido']='Este Código de Ética esboza la identidad de la Asociación y expone la forma en que desarrolla su labor asociativa. Prioriza las relaciones humanas y el fortalecimiento de la identidad del Valle de San Antonio. El  sueño es llevar la marca San Antonio al mundo como sinónimo de vinos de excelencia, de la mano de su gente y su cultura,  en un lugar de Chile que definimos como territorio de Vino , Mar y Poesía.
        La Asociación fue creada en junio de 2019, su finalidad es la difusión, promoción, desarrollo y protección del Valle de San Antonio y de la Denominación de origen de sus cepas emblemáticas y resguardo del medioambiente en que este se desarrolla y la producción sustentable de sus vinos, así como el fomento y apoyo al enoturismo y gastronomía vinculada al Valle.';
        $data['contenido'][1]['titulo']='Valores fundamentales de AVVSA:';
        $data['contenido'][1]['contenido']='';
        $data['contenido'][1]['lista']='Sustentabilidad-Identidad de terroir-Calidad-Desarrollo local-Asociatividad';
        $data['contenido'][2]['titulo']='PRINCIPIOS GENERALES';
        $data['contenido'][2]['contenido']='El presente Código de Ética Gremial es un referente institucional de la conducta personal y profesional que deben cumplir todos los socios de AVVSA, independiente del cargo o función que desempeñen.  Representa un propósito gremial  y un compromiso personal que se asume con responsabilidad. La sumatoria de las conductas éticas individuales contribuye a la construcción de una imagen positiva de AVVSA y sus empresas afiliadas, cuyo resultado debe ser una cultura empresarial que tiene sustento en principios y valores.
        Los socios de AVVSA , deben adoptar y comprometerse a cumplir con los siguientes valores:';
        $data['contenido'][2]['extras'][0]['subTitulo']='Transparencia';
        $data['contenido'][2]['extras'][0]['bajada']='Consiste en realizar todas las actividades correctamente, de manera clara y apropiada, mostrando que todos los actos son realizados con visibilidad pública y abierta a la comunidad.';
        $data['contenido'][2]['extras'][1]['subTitulo']='Veracidad';
        $data['contenido'][2]['extras'][1]['bajada']='Se entiende como la entrega al otro de los datos o informaciones, que tiene derecho a saber, para tomar sus decisiones. Significa mucho más que evitar “decir algo falso”.';
        $data['contenido'][2]['extras'][2]['subTitulo']='Integridad';
        $data['contenido'][2]['extras'][2]['bajada']='Cumplir rigurosamente con las políticas, procedimientos y prácticas, adoptadas por la Asociación para fomentar una “Cultura Ética”, orientada por la credibilidad y la confianza, que permitan la convivencia con rectitud, probidad y honestidad.';
        $data['contenido'][2]['extras'][3]['subTitulo']='Responsabilidad';
        $data['contenido'][2]['extras'][3]['bajada']=' Todos y cada uno de los socios  deben responder por sus actos. Todas las acciones tienen consecuencias frente a los demás, a la sociedad, frente a la Empresa y a nosotros mismos, por tanto debe haber un alto compromiso con los principios, valores y disposiciones adoptadas mediante el presente Código de Ética.';
        $data['contenido'][2]['extras'][4]['subTitulo']='Respeto';
        $data['contenido'][2]['extras'][4]['bajada']='Tratemos a los demás como nos gustaría que ellos lo hiciesen con nosotros. Para ser dignos de confianza, los demás esperan de nosotros un trato justo.';
        $data['contenido'][3]['titulo']='Conflictos de interés';
        $data['contenido'][3]['contenido']='Para preservar la integridad personal y profesional de los directivos y colaboradores de la Asociación, debemos evitar situaciones que puedan generar conflicto entre los intereses personales y los de la Asociación.
        Se deben evitar acciones mediante las cuales se puedan obtener beneficios personales o para terceros.
        En el caso de contratación de parientes se debe pedir autorización al Directorio de AVVSA.
        Está prohibido manipular o valerse de informaciones sobre la Asociación o de sus socios en provecho personal, beneficio o perjuicio a terceros.
        Se debe mantener la confidencialidad de las informaciones internas de la Asociación, es decir, de las informaciones que no sean de dominio público.';
        $data['contenido'][4]['titulo']='Transparencia y gestión';
        $data['contenido'][4]['contenido']='La Asociación actuará en todo momento respetando la legislación vigente en el país.
        La gestión de la Asociación deberá ser responsable, comprometida con el logro de los objetivos de la organización.
        Facilitará a todo aquel que lo solicite información sobre sus acciones, programas, objetivos, forma de obtención de recursos, cantidad de los mismos, y composición de sus órganos directivos y ejecutivos.
        Publicará anualmente una memoria con información sobre sus actividades, programas, recursos, balance financiero y órganos directivos.
        Responsabilidad de directivos y empleados.
        Los directivos y empleados de la Asociación tienen el deber de comportarse en derecho con la organización, respetar a las personas que la integran o que interactúan con ella, cumplir sus funciones con esmero y diligencia y mantener la confidencialidad o reserva de la información privada de la organización.
        Los directivos y empleados de la Asociación respetarán la vida privada y la honra de cada una de las personas que la integran.
        Los directivos y empleados deberán responder ante la organización y ante terceros, en su caso, por los daños que ocasionaren por su actuación dolosa, negligente o imprudente.
        ';
        $data['contenido'][5]['titulo']='Recursos económicos';
        $data['contenido'][5]['contenido']='La Asociación se financiará a través de la cuota mensual establecida por sus socios.
        Toda la actividad de captación de fondos que realice la Asociación deberá ajustarse al marco legal.
        Los proyectos desarrollados en cofinanciamiento o con financiamiento externo en su totalidad serán debidamente rendidos y sus gastos informados en la memoria anual. Información disponible para todo aquel que la solicite.';
        $data['contenido'][6]['titulo']='FORMAS DE ACCION';
        $data['contenido'][6]['contenido']='La Asociación colabora con estrategias y acciones de difusión tanto para sus socios como para el Valle a través de: Actividades conjuntas de marketing y difusión, que permitan ampliar el conocimiento cualitativo de los vinos de las viñas asociadas. Acciones tendientes a fortalecer el conocimiento de los vinos de los Asociados dentro del valle mediante estrategias de alianzas con los restaurantes del valle que compartan metas de calidad e identidad enogastronómica.   El apoyo y asesoría técnica a restaurantes a través de capacitaciones, elaboraciones de cartas de vino  a la medida que permitan mejorar el servicio y la oferta enológica. Selección gastronómica anual de platos a ofertar en evento de vendimia del valle.
        Seguimiento y sistematización de las acciones realizadas.  para evaluar el impacto ante los consumidores finales y construir estrategias orientadas a mejorar la calidad de la cooperación.
        El apoyo en la información y sensibilización, hacia los aliados estratégicos y la opinión pública, en temas de difusión o educación, que faciliten una mejor comprensión enológica del valle, del adecuado consumo del vino, de la sustentabilidad de los viñedos y del entorno, entre otros temas de interés común. La promoción de valores ambientales, culturales y de respeto congruentes con los principios declarados.
        La realización de proyectos de información, intercambio de conocimientos y experiencias, a partir  de la experiencia propia y de los equipos asesores. Estas acciones se concretarán en publicaciones digitales, seminarios y talleres.
        La realización de proyectos de investigación, desafíos de cambio climático, alternativas de abastecimiento hídrico, fortalecimiento de la sustentabilidad. Acciones a realizar en alianza público privada.';
        $data['contenido'][7]['titulo']='RELACION CON LA PRENSA';
        $data['contenido'][7]['contenido']='Siendo la difusión uno objetivo central para AVVSA, la prensa resulta ser es un actor relevante para su cumplimiento. Se trata de ampliar el conocimiento sobre la calidad y bondades del Valle de San Antonio. El primer aspecto es el respeto a la libertad de opinión y a la tarea comunicacional.. La información se entregará con la debida transparencia, propiciando el conocimiento enológico objetivo. Cada vez que se invite a uno o más periodistas a visitar el Valle, la invitación se realizará con acuerdo pleno de los socios de AVVSA y serán tratados con absoluto respeto por su persona y oficio. En cada acción comunicacional AVVSA asumirá la responsabilidad de respaldar la entrega de información técnica por escrito, mediante dossier u otro similar. A su vez, incentivará la participación activa de todos sus socios por igual.';
        prx(json_encode($data, JSON_UNESCAPED_UNICODE));
        $this->loadModel('Contenido');
        $this->Contenido->id=5;
        $dataSave['Contenido']['id']=5;
        $dataSave['Contenido']['contenido_es']=json_encode($data, JSON_UNESCAPED_UNICODE);
    }
}







 










