<?
namespace App\Model\Entity;

use Cake\ORM\Entity;

class Vina extends Entity
{

}